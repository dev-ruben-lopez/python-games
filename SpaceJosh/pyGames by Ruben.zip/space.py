#from tkinter import font
#import fontTools
import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 800
CANNON_SPEED = 5
BULLET_SPEED = 10
ENEMY_SPEED = 1

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Create the game window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Invaders")

# Initialize cannon
#cannon = pygame.Rect(WIDTH // 2 - 30, HEIGHT - 50, 60, 20)
cannon = pygame.Rect(WIDTH // 2 - 20, HEIGHT - 50, 40, 20)
cannon_barrel = pygame.Rect(WIDTH // 2 - 5, HEIGHT - 90, 10, 40)

# Initialize sound effects
pygame.mixer.init()
shoot_sound = pygame.mixer.Sound("sounds/shoot1.flac")  
win_sound = pygame.mixer.Sound("sounds/win.wav")  
lose_sound = pygame.mixer.Sound("sounds/game_over.wav")  

# Initialize game state
game_over = False
new_game = False
enemies_number = 2
# Initialize bullets
bullets = []
# Initialize enemies
enemies = [pygame.Rect(random.randint(10, WIDTH - 10), random.randint(50, 200), 20, 20) for _ in range(enemies_number)]
# Fonts
font = pygame.font.Font(None, 36)


# Main game loop
while not game_over:
    
    if new_game:
        # increase enemies
        enemies_number += 1
        # Restart  bullets
        bullets = []
        # restart enemies
        enemies = [pygame.Rect(random.randint(10, WIDTH - 10), random.randint(50, 200), 20, 20) for _ in range(enemies_number)]
        # wait for this game to end
        new_game = False
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game_over = True

    if not game_over:
        keys = pygame.key.get_pressed()
        
        if keys[pygame.K_LEFT]:
            cannon.x -= CANNON_SPEED
            cannon_barrel.x -= CANNON_SPEED
        if keys[pygame.K_RIGHT]:
            cannon.x += CANNON_SPEED
            cannon_barrel.x += CANNON_SPEED
        if keys[pygame.K_SPACE]:
            bullet = pygame.Rect(cannon.centerx - 2, cannon.top, 4, 10)
            bullets.append(bullet)
            shoot_sound.play()

        # Update bullet positions
        bullets = [bullet for bullet in bullets if bullet.y > 0]
        for bullet in bullets:
            bullet.y -= BULLET_SPEED

        # Update enemy positions
        for enemy in enemies:
            enemy.y += ENEMY_SPEED

        # Check for collisions
        for bullet in bullets:
            for enemy in enemies:
                if bullet.colliderect(enemy):
                    bullets.remove(bullet)
                    enemies.remove(enemy)

        # Check if any enemy reached the bottom
        for enemy in enemies:
            if enemy.bottom >= HEIGHT:
                #game_over = True
                lose_sound.play()
                loser_message = font.render("You Lost!", True, RED)
                screen.blit(loser_message, (WIDTH // 2 - 120, HEIGHT // 2 - 18))
                pygame.display.flip()
                pygame.time.delay(2000)
                 # Wait for a key press to restart the game
                waiting_for_restart = True
                while waiting_for_restart:
                    for event in pygame.event.get():
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                pygame.QUIT
                                game_over = True
                                waiting_for_restart = False
                            else:
                                waiting_for_restart = False     
                                new_game = True
                        if event.type == pygame.QUIT:
                            game_over = True
                            waiting_for_restart = False

        # Check if all enemies are destroyed
        if not enemies:
            win_sound.play()
            winner_message = font.render("Player  Wins!", True, GREEN)
            screen.blit(winner_message, (WIDTH // 2 - 120, HEIGHT // 2 - 18))
            pygame.display.flip()
            pygame.time.delay(2000)
            # Wait for a key press to restart the game
            waiting_for_restart = True
            while waiting_for_restart:
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            pygame.QUIT
                            game_over = True
                            waiting_for_restart = False
                        else:
                            waiting_for_restart = False     
                            new_game = True
                    if event.type == pygame.QUIT:
                        game_over = True
                        waiting_for_restart = False

        # Clear the screen
        screen.fill(BLACK)

        # Draw cannon
        pygame.draw.rect(screen, GREEN, cannon)
        pygame.draw.rect(screen, GREEN, cannon_barrel)

        # Draw bullets
        for bullet in bullets:
            pygame.draw.rect(screen, WHITE, bullet)

        # Draw enemies
        for enemy in enemies:
            pygame.draw.rect(screen, RED, enemy)

        # Update the display
        pygame.display.flip()

        # Control game speed (FPS)
        pygame.time.Clock().tick(60)
